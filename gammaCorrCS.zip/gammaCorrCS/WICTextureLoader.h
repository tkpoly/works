
//�摜�t�@�C�����[�_�[���쐬���쐬���܂��B


//#pragma once

#ifdef _MSC_VER
#pragma once
#endif

#include <d3d11.h>
#include <wincodec.h>
#include <memory>

#pragma warning(push)
#pragma warning(disable : 4005)
#include <stdint.h>
#pragma warning(pop)

HRESULT CreateWICTextureFromFile(
    ID3D11Device* device,
    ID3D11DeviceContext* context,
    const wchar_t* fileName,
    ID3D11Texture2D** outTex,
    ID3D11ShaderResourceView** outSRV,
    size_t maxSize = 0);

HRESULT CreateWICTextureFromMemory(
    ID3D11Device* device,
    ID3D11DeviceContext* context,
    const uint8_t* data,
    size_t dataSize,
    ID3D11Texture2D** outTex,
    ID3D11ShaderResourceView** outSRV,
    size_t maxSize = 0);


// CWICTextureLoader

class CWICTextureLoader
{
public:
    CWICTextureLoader();
    ~CWICTextureLoader();
};
