// WICTextureLoader.cpp : �����t�@�C��
//

// ModernWICTextureLoader.cpp

#include "pch.h"
#include "WICTextureLoader.h"
#include <assert.h>


template<class T>
class ScopedCOM
{
public:
    ScopedCOM() : p(nullptr) {}
    ~ScopedCOM() { if (p) { p->Release(); p = nullptr; } }
    T* Get() const { return p; }
    T** operator&() { return &p; }
    T* operator->() { return p; }
private:
    T* p;
};

static IWICImagingFactory* GetWIC()
{
    static IWICImagingFactory* s_factory = nullptr;
    if (s_factory) return s_factory;

    HRESULT hr = CoCreateInstance(
        CLSID_WICImagingFactory,
        nullptr,
        CLSCTX_INPROC_SERVER,
        __uuidof(IWICImagingFactory),
        reinterpret_cast<void**>(&s_factory));

    if (FAILED(hr))
    {
        s_factory = nullptr;
        return nullptr;
    }
    return s_factory;
}

static HRESULT CreateTextureFromWICFrame(
    ID3D11Device* device,
    ID3D11DeviceContext* context,
    IWICBitmapFrameDecode* frame,
    ID3D11Texture2D** outTex,
    ID3D11ShaderResourceView** outSRV,
    size_t maxSize)
{
    if (!device || !frame || (!outTex && !outSRV))
        return E_INVALIDARG;

    UINT width = 0, height = 0;
    HRESULT hr = frame->GetSize(&width, &height);
    if (FAILED(hr) || width == 0 || height == 0)
        return hr;

    UINT tw = width;
    UINT th = height;

    if (maxSize)
    {
        if (tw > maxSize || th > maxSize)
        {
            float ar = float(th) / float(tw);
            if (tw >= th)
            {
                tw = UINT(maxSize);
                th = UINT(float(maxSize) * ar);
            }
            else
            {
                th = UINT(maxSize);
                tw = UINT(float(maxSize) / ar);
            }
        }
    }

    IWICImagingFactory* wic = GetWIC();
    if (!wic)
        return E_NOINTERFACE;

    ScopedCOM<IWICBitmapSource> source;
    frame->QueryInterface(IID_PPV_ARGS(&source));

    ScopedCOM<IWICBitmapScaler> scaler;
    if (tw != width || th != height)
    {
        hr = wic->CreateBitmapScaler(&scaler);
        if (FAILED(hr)) return hr;

        hr = scaler->Initialize(frame, tw, th, WICBitmapInterpolationModeFant);
        if (FAILED(hr)) return hr;

        scaler->QueryInterface(IID_PPV_ARGS(&source));
    }

    ScopedCOM<IWICFormatConverter> converter;
    hr = wic->CreateFormatConverter(&converter);
    if (FAILED(hr)) return hr;

    hr = converter->Initialize(
        source.Get(),
        GUID_WICPixelFormat32bppRGBA,
        WICBitmapDitherTypeNone,
        nullptr,
        0.0,
        WICBitmapPaletteTypeCustom);
    if (FAILED(hr)) return hr;

    const DXGI_FORMAT texFormat = DXGI_FORMAT_R8G8B8A8_UNORM;
    const UINT bpp = 32;
    size_t rowPitch = (size_t(tw) * bpp) / 8;
    size_t imageSize = rowPitch * size_t(th);

    std::unique_ptr<uint8_t[]> pixels(new uint8_t[imageSize]);

    hr = converter->CopyPixels(
        nullptr,
        UINT(rowPitch),
        UINT(imageSize),
        pixels.get());
    if (FAILED(hr)) return hr;

    bool autogen = false;
    if (context && outSRV)
    {
        UINT support = 0;
        if (SUCCEEDED(device->CheckFormatSupport(texFormat, &support)) &&
            (support & D3D11_FORMAT_SUPPORT_MIP_AUTOGEN))
        {
            autogen = true;
        }
    }

    D3D11_TEXTURE2D_DESC desc = {};
    desc.Width = tw;
    desc.Height = th;
    desc.MipLevels = autogen ? 0 : 1;
    desc.ArraySize = 1;
    desc.Format = texFormat;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = autogen
        ? (D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET)
        : D3D11_BIND_SHADER_RESOURCE;
    desc.CPUAccessFlags = 0;
    desc.MiscFlags = autogen ? D3D11_RESOURCE_MISC_GENERATE_MIPS : 0;

    D3D11_SUBRESOURCE_DATA init = {};
    init.pSysMem = pixels.get();
    init.SysMemPitch = UINT(rowPitch);

    ScopedCOM<ID3D11Texture2D> tex;
    hr = device->CreateTexture2D(
        &desc,
        autogen ? nullptr : &init,
        &tex);
    if (FAILED(hr)) return hr;

    if (autogen)
    {
        context->UpdateSubresource(
            tex.Get(), 0, nullptr,
            pixels.get(), UINT(rowPitch), 0);
    }

    if (outSRV)
    {
        D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
        srvDesc.Format = texFormat;
        srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srvDesc.Texture2D.MipLevels = autogen ? -1 : 1;

        hr = device->CreateShaderResourceView(
            tex.Get(), &srvDesc, outSRV);
        if (FAILED(hr)) return hr;

        if (autogen)
            context->GenerateMips(*outSRV);
    }

    if (outTex)
    {
        *outTex = tex.Get();
        (*outTex)->AddRef();
    }

    return S_OK;
}

HRESULT CreateWICTextureFromFile(
    ID3D11Device* device,
    ID3D11DeviceContext* context,
    const wchar_t* fileName,
    ID3D11Texture2D** outTex,
    ID3D11ShaderResourceView** outSRV,
    size_t maxSize)
{
    if (!device || !fileName || (!outTex && !outSRV))
        return E_INVALIDARG;

    if (maxSize == 0)
    {
        maxSize = 16384;
    }

    IWICImagingFactory* wic = GetWIC();
    if (!wic) return E_NOINTERFACE;

    ScopedCOM<IWICBitmapDecoder> decoder;
    HRESULT hr = wic->CreateDecoderFromFilename(
        fileName, nullptr, GENERIC_READ,
        WICDecodeMetadataCacheOnDemand,
        &decoder);
    if (FAILED(hr)) return hr;

    ScopedCOM<IWICBitmapFrameDecode> frame;
    hr = decoder->GetFrame(0, &frame);
    if (FAILED(hr)) return hr;

    return CreateTextureFromWICFrame(
        device, context, frame.Get(),
        outTex, outSRV, maxSize);
}

HRESULT CreateWICTextureFromMemory(
    ID3D11Device* device,
    ID3D11DeviceContext* context,
    const uint8_t* data,
    size_t dataSize,
    ID3D11Texture2D** outTex,
    ID3D11ShaderResourceView** outSRV,
    size_t maxSize)
{
    if (!device || !data || dataSize == 0 || (!outTex && !outSRV))
        return E_INVALIDARG;
    
    if (maxSize == 0)
    {
        maxSize = 16384;
    }

    IWICImagingFactory* wic = GetWIC();
    if (!wic) return E_NOINTERFACE;

    ScopedCOM<IWICStream> stream;
    HRESULT hr = wic->CreateStream(&stream);
    if (FAILED(hr)) return hr;

    hr = stream->InitializeFromMemory(
        const_cast<uint8_t*>(data),
        static_cast<DWORD>(dataSize));
    if (FAILED(hr)) return hr;

    ScopedCOM<IWICBitmapDecoder> decoder;
    hr = wic->CreateDecoderFromStream(
        stream.Get(), nullptr,
        WICDecodeMetadataCacheOnDemand,
        &decoder);
    if (FAILED(hr)) return hr;

    ScopedCOM<IWICBitmapFrameDecode> frame;
    hr = decoder->GetFrame(0, &frame);
    if (FAILED(hr)) return hr;

    return CreateTextureFromWICFrame(
        device, context, frame.Get(),
        outTex, outSRV, maxSize);
}





// CWICTextureLoader

CWICTextureLoader::CWICTextureLoader()
{

}

CWICTextureLoader::~CWICTextureLoader()
{
}


// CWICTextureLoader ���b�Z�[�W �n���h���[


