﻿
// gammaCorrCSDlg.cpp : 実装ファイル
//

#include "pch.h"
#include "framework.h"
#include "gammaCorrCS.h"
#include "gammaCorrCSDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// アプリケーションのバージョン情報に使われる CAboutDlg ダイアログ

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

// 実装
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CgammaCorrCSDlg ダイアログ



CgammaCorrCSDlg::CgammaCorrCSDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_GAMMACORRCS_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CgammaCorrCSDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CgammaCorrCSDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CgammaCorrCSDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CgammaCorrCSDlg::OnBnClickedCancel)
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()

	ON_MESSAGE(WM_BT, OnBT)	//BT0クラスからのポストメッセージ
	ON_MESSAGE(WM_Edit, OnEdit)	//editImageDlgクラスからのポストメッセージ

	ON_WM_TIMER()
	ON_WM_MOVING()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()


// CgammaCorrCSDlg メッセージ ハンドラー

BOOL CgammaCorrCSDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// "バージョン情報..." メニューをシステム メニューに追加します。

	// IDM_ABOUTBOX は、システム コマンドの範囲内になければなりません。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// このダイアログのアイコンを設定します。アプリケーションのメイン ウィンドウがダイアログでない場合、
	//  Framework は、この設定を自動的に行います。
	SetIcon(m_hIcon, TRUE);			// 大きいアイコンの設定
	SetIcon(m_hIcon, FALSE);		// 小さいアイコンの設定

	// TODO: 初期化をここに追加します。
	pDC = GetDC();

	brBlack.CreateSolidBrush(RGB(0, 0, 0));//背景色用ブラシ

	SetWindowPos(&wndTop, 10, 10, 1800, 1012, SWP_SHOWWINDOW);

	WText = _T("gammaCorrCS");
	getWsize();

	//仮のテクスチャ 黒（αチャネル付き32bitフルカラーバッファ）
	ImgTex.Destroy();
	imgW = 1920;
	imgH = 1080;
	ImgTex.CreateEx(imgW, imgH, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcTex = CDC::FromHandle(ImgTex.GetDC());
	pdcTex->SetStretchBltMode(COLORONCOLOR);
	hdcTex = pdcTex->GetSafeHdc();	//GDI+用
	RECT rect = { 0,0,imgW,imgH };
	pdcTex->FillRect(&rect, &brBlack);

	//directX11の初期化-----------------------------------------
	hWnd = GetSafeHwnd();

	if (dx11.InitDevice(hWnd, (UINT)Width, (UINT)Height) == S_OK)
	{
		dx11.Render();
		fg_DX11 = 1;
	}
	else {
		MessageBox(_T("DirectX11を初期化できません　"), MB_OK);
	}


	//ボタン---------------------------------------------------------------------------------
	//BT0のインスタンス作成（メインボタン）
	bt0 = new CbuttonDlg(this);
	bt0->ShowWindow(SW_SHOW);
	RECT wrect;
	GetWindowRect(&wrect);
	bt0->setWpos(wrect.right - 10 - bt0->Width, wrect.top + 40, SWP_SHOWWINDOW);


	//CEditImgDlgクラスの初期化------------------------------------------------
	ediDlg = new CeditImgDlg(this);
	ediDlg->ShowWindow(SW_HIDE);
	ediDlg->setWPos(wrect.right - 480, wrect.top + 40);



	return TRUE;  // フォーカスをコントロールに設定した場合を除き、TRUE を返します。
}

void CgammaCorrCSDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// ダイアログに最小化ボタンを追加する場合、アイコンを描画するための
//  下のコードが必要です。ドキュメント/ビュー モデルを使う MFC アプリケーションの場合、
//  これは、Framework によって自動的に設定されます。

void CgammaCorrCSDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 描画のデバイス コンテキスト

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// クライアントの四角形領域内の中央
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// アイコンの描画
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
		if (fg_Window == 1) {
			if (fg_1shot == 0) {
				//何もしない
				fg_1shot = 1;
			}
			else {
				if (fg_DX11 == 1) {
					dx11.Render();
				}
			}
			this->SetWindowText(WText);
		}
	}
}

// ユーザーが最小化したウィンドウをドラッグしているときに表示するカーソルを取得するために、
//  システムがこの関数を呼び出します。
HCURSOR CgammaCorrCSDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



//メッセージハンドラ/////////////////////////////////////////////////////////////////
//ダイアログの背景色を変更する*******************************************
HBRUSH CgammaCorrCSDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ここで DC の属性を変更してください。

	fg_Window = 1;

	// TODO:  既定値を使用したくない場合は別のブラシを返します。
	switch (nCtlColor)
	{
	case CTLCOLOR_DLG:
		hbr = (HBRUSH)brBlack;

	default:	break;
	}

	return hbr;
}

//クライアント領域の大きさを取得**********************************************
void CgammaCorrCSDlg::getWsize()
{
	RECT rect;
	//クライアント領域の寸法を取得-------------
	GetClientRect(&rect);
	Width = (int)rect.right;;
	Height = (int)rect.bottom;

}



//ウィンドウを移動中************************************************************************
void CgammaCorrCSDlg::OnMoving(UINT fwSide, LPRECT pRect)
{
	CDialogEx::OnMoving(fwSide, pRect);

	RECT wrect;
	GetWindowRect(&wrect);
	int A = 0;
	if (wrect.top < 0) {
		A = wrect.top;
	}

	//ボタンダイアログをウィンドウに合わせて移動
	bt0->setWpos(wrect.right - 10 - bt0->Width, wrect.top - A + 40, SWP_SHOWWINDOW);
}



//ＯＫボタン***********************************
void CgammaCorrCSDlg::OnBnClickedOk()
{
	return;

	CDialogEx::OnOK();
}



//キャンセルボタン又は、×ボタン******************************
void CgammaCorrCSDlg::OnBnClickedCancel()
{
	KillTimer(1);

	dx11.cleanupDevice();	//directXの開放
	DeleteObject(brBlack);

	ReleaseDC(pDC);

	ImgTex.ReleaseDC();
	ReleaseDC(pdcTex);
	DeleteDC(hdcTex);

	//BT0の終了
	delete bt0;

	//ediDlgの終了
	delete ediDlg;

	CDialogEx::OnCancel();
}




//マウスのＬボタン・ダウン******************************************************
void CgammaCorrCSDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	POINT	mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxD = mspoint.x;
	myD = mspoint.y;

	bfmxM = mxD;
	bfmyM = myD;

	fg_scroll = 0;
	dx11.trlXB = 0;
	dx11.trlYB = 0;

	//スクロールを許可
	if (mxD > 0 && mxD < Width - bt0->Width && myD>0 && myD < Height)
	{
		::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_HAND));
		fg_scroll = 1;
	}

	CDialogEx::OnLButtonDown(nFlags, point);
}


//マウスを移動中***********************************************************************
void CgammaCorrCSDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	POINT	mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxM = mspoint.x;
	myM = mspoint.y;

	if (mxM != bfmxM || myM != bfmyM)
	{
		//画像のスクロール（フォブ変換を使用しない場合）
		if (nFlags == MK_LBUTTON && fg_scroll == 1) {
			dx11.trlX = (float)(mxM - mxD) / 30.0f * (-dx11.eyeZ / 100.0f);
			dx11.trlY = -(float)(myM - myD) / 30.0f * (-dx11.eyeZ / 100.0f);
			dx11.trlZ = 0.0f;

			dx11.Render();
		}


	}
	bfmxM = mxM;
	bfmyM = myM;

	CDialogEx::OnMouseMove(nFlags, point);
}




//マウスのＬボタン・アップ************************************************************
void CgammaCorrCSDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	KillTimer(1);

	POINT	mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxU = mspoint.x;
	myU = mspoint.y;

	int ret = 0;
	float spe = 0.0f;
	float ref = 0.0f;

	//スクロールのバックアップ
	if (fg_scroll == 1) {

		dx11.trlZ = 0.0f;

		int j;

		for (j = 0; j < 4; j++)
		{
			dx11.Bprim.x[j] = dx11.Bprim.x[j] + dx11.trlX;
			dx11.Bprim.y[j] = dx11.Bprim.y[j] + dx11.trlY;
			dx11.Bprim.z[j] = dx11.Bprim.z[j] + dx11.trlZ;
		}

		dx11.sPT.x = dx11.sPT.x + dx11.trlX;
		dx11.sPT.y = dx11.sPT.y + dx11.trlY;
		dx11.sPT.z = dx11.sPT.z + dx11.trlZ;

		dx11.trlX = 0.0f;
		dx11.trlY = 0.0f;
		dx11.trlZ = 0.0f;

		dx11.setData();
	}

	fg_scroll = 0;

	dx11.Render();

	CDialogEx::OnLButtonUp(nFlags, point);
}


//editImageDlgを開く******************************
void  CgammaCorrCSDlg::showEdiDlg()
{
	if (FPath != _T("")) {
		ediDlg->ShowWindow(SW_SHOW);
	}
}

//BT0からのメッセージ（メイン・ボタン）**********************************************
LRESULT  CgammaCorrCSDlg::OnBT(WPARAM wParam, LPARAM lParam)
{
	if (lParam == 0) {
		return 0;
	}

	switch (wParam) {

	case 0: //開く
		loadImage();
		break;

	case 1: //保存
		if (FPath != _T("")) {
			saveImage();
		}
		break;

	case 2://Focus
		dx11.focus(0);
		ediDlg->fg_post = 0;
		break;

	case 3: //ediDlgオープン
		if (FPath != _T("")) {
			ediDlg->ShowWindow(SW_SHOW);
		}
		ediDlg->fg_post = 0;
		break;

	default:
		break;
	}

	return 0;
}

//editImgからのメッセージ（メイン・ボタン）**************************************
LRESULT  CgammaCorrCSDlg::OnEdit(WPARAM wParam, LPARAM lParam)
{
	switch (wParam) {


	case 0: //ガンマ値が決まった
		gamma();
		break;

	default:
		break;
	}

	return 0;
}


//トーンカーブによるガンマ補正****************************************************
void CgammaCorrCSDlg::gamma()
{
	if (ediDlg == nullptr) {
		return;
	}

	//Gamma値
	for (int i = 0; i < 256; i++) {
		if (ediDlg->fg_R == 1) {
			dx11.Gamma[i].x = ediDlg->gamY[i];
		}
		else {
			dx11.Gamma[i].x = 1.0f;
		}

		if (ediDlg->fg_G == 1) {
			dx11.Gamma[i].y = ediDlg->gamY[i];
		}
		else {
			dx11.Gamma[i].y = 1.0f;
		}

		if (ediDlg->fg_B == 1) {
			dx11.Gamma[i].z = ediDlg->gamY[i];
		}
		else {
			dx11.Gamma[i].z = 1.0f;
		}
	}


	//コンピュート・シェーダー--------------------------------------
	//ガンマ補正
	dx11.runCSGamma();

	//ヒストグラム用データの取得
	dx11.runCSHist();

	//新しい画像を読み込んだ時、1回だけ倍率を求める
	int i;
	if (fg_1shot1 == 0) {
		fg_1shot1 = 1;

		UINT maxR, maxG, maxB, maxH;
		histmag = 1.0f;

		maxR = 0;
		maxG = 0;
		maxB = 0;
		for (i = 20; i < 240; i++) {//適当な範囲で最大値を求める
			if (dx11.histR[i] > maxR) { maxR = dx11.histR[i]; }
			if (dx11.histG[i] > maxG) { maxG = dx11.histG[i]; }
			if (dx11.histB[i] > maxB) { maxB = dx11.histB[i]; }
		}

		maxH = 1;
		if (maxR > maxH) { maxH = maxR; }
		if (maxG > maxH) { maxH = maxG; }
		if (maxB > maxH) { maxH = maxB; }

		histmag = 255.0f / (float)maxH;
	}

	ediDlg->fg_post = 0;

	for (i = 1; i < 257; i++) {
		ediDlg->gPtR[i].X = (float)i + (float)ediDlg->ofX;
		ediDlg->gPtR[i].Y = (float)ediDlg->ofY + 255.0f - (float)dx11.histR[i] * histmag;

		ediDlg->gPtG[i].X = (float)i + (float)ediDlg->ofX;;
		ediDlg->gPtG[i].Y = (float)ediDlg->ofY + 255.0f - (float)dx11.histG[i] * histmag;

		ediDlg->gPtB[i].X = (float)i + (float)ediDlg->ofX;;
		ediDlg->gPtB[i].Y = (float)ediDlg->ofY + 255.0f - (float)dx11.histB[i] * histmag;
	}

	//ヒストグラムを描画
	ediDlg->drawHG();

	dx11.Render();

}


//zoom Up/Down*****************************************************************
BOOL CgammaCorrCSDlg::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	float K = 0.002f;  // 初速係数（調整できる）
	zV += -(float)zDelta * K;
	SetTimer(1, 10, NULL);

	return CDialogEx::OnMouseWheel(nFlags, zDelta, pt);
}


//タイマー********************************************************************
void CgammaCorrCSDlg::OnTimer(UINT_PTR nIDEvent)
{
	float base;
	float zStep;

	switch (nIDEvent)
	{
	case 1:
		zV *= 0.93f;   // 摩擦（0.85～0.95で調整）

		base = dx11.eyeZ * 0.016f;   // 距離に応じたズーム量
		zStep = base * zV;

		dx11.zoom(zStep);   // 視点ズーム

		if (fabs(zV) < 0.05f) {
			zV = 0.0f;
			KillTimer(1);
		}
		break;

	default:break;

	}


	CDialogEx::OnTimer(nIDEvent);
}




//イメージのロード******************************************************************************************************
HRESULT CgammaCorrCSDlg::loadImage()
{
	int ret;

	CString strFilter;
	strFilter = _T("すべて|*.*|.jpg|*.jpg|.png|*.png|.bmp|*.bmp|");

	CFileDialog frDlg(TRUE, _T("*.*"), NULL, OFN_FILEMUSTEXIST, strFilter);
	frDlg.m_ofn.nFilterIndex = m_nFilterLoad;
	ret = (int)frDlg.DoModal();
	if (ret != IDOK) {
		return S_FALSE;
	}

	CString fname = frDlg.GetFileName();
	CString fpath = frDlg.GetPathName();

	FName = fname;
	FPath = fpath;

	//画像のロード
	if (dx11.loadTexture(fpath) == S_OK) {

		imgW = dx11.imgWidth;
		imgH = dx11.imgHeight;

		//CreateWICTextureFromFileで自動リサイズされるが、一応画像の大きさを制限
		if (imgW > 17000 || imgH > 17000) {
			return S_FALSE;
		}

		//画像をテクスチャとして表示するための四角形ポリゴンを作成
		dx11.makePolygon();
		fg_texON = 1;

		ediDlg->reset();
		ediDlg->redraw();
		fg_1shot1 = 0;
		gamma();

		//ピクセル・シェーダーによる描画
		dx11.Render();

		//GDI編集、セーブ用のバッファ（CImage）を作成、
		if (ImgTex != NULL) { ImgTex.ReleaseDC(); }
		ImgTex.Destroy();
		ImgTex.CreateEx(imgW, imgH, 32, BI_RGB, 0, CImage::createAlphaChannel);
		pdcTex = CDC::FromHandle(ImgTex.GetDC());
		pdcTex->SetStretchBltMode(COLORONCOLOR);
		hdcTex = pdcTex->GetSafeHdc();
		RECT rect = { 0,0,imgW,imgH };
		pdcTex->FillRect(&rect, &brBlack);


		//タイトルバーに画像の情報を表示
		strW.Format(_T("%d"), imgW);
		strH.Format(_T("%d"), imgH);

		WText = _T("gammaCorrCS           ") + FPath +
			_T("       ") + strW + _T("　X　") + strH;

		this->SetWindowText(WText);
		return S_OK;
	}

	return E_FAIL;
}



//save Image************************************************************************
void CgammaCorrCSDlg::saveImage()
{
	CString strFilter;
	strFilter = _T("すべて|*.*|.jpg|*.jpg|.png|*.png|.bmp|*.bmp|.tif|*.tif|.gif|*.gif");

	CFileDialog wfDlg(FALSE, _T(".jpg"), _T("無題.jpg"), OFN_HIDEREADONLY |
		OFN_OVERWRITEPROMPT | OFN_EXPLORER, strFilter);
	wfDlg.m_ofn.nFilterIndex = m_nFilterLoad;
	INT_PTR ret = wfDlg.DoModal();
	if (ret != IDOK) {
		return;
	}

	sFName = wfDlg.GetFileName();
	sFPath = wfDlg.GetPathName();

	m_nFilterLoad = wfDlg.m_ofn.nFilterIndex;

	dx11.fg_save = 1;
	dx11.hdcTex = hdcTex;
	gamma();

	CImage	imgSave;
	imgSave.Destroy();
	imgSave.CreateEx(imgW, imgH, 32, BI_RGB, 0, CImage::createAlphaChannel);
	CDC* pdcSave = CDC::FromHandle(imgSave.GetDC());

	pdcSave->StretchBlt(0, 0, imgW, imgH, pdcTex, 0, 0, imgW, imgH, SRCCOPY);

	CString strS = sFName.Right(4);

	if (strS == _T(".png") || strS == _T(".PNG")) {
		imgSave.Save(sFPath, Gdiplus::ImageFormatPNG);
	}
	else if (strS == _T(".jpg") || strS == _T(".JPG")) {
		imgSave.Save(sFPath, Gdiplus::ImageFormatJPEG);
	}
	else if (strS == _T(".bmp") || strS == _T(".BMP")) {
		imgSave.Save(sFPath, Gdiplus::ImageFormatBMP);
	}
	else if (strS == _T(".tif") || strS == _T(".TIF")) {
		imgSave.Save(sFPath, Gdiplus::ImageFormatTIFF);
	}
	else if (strS == _T(".gif") || strS == _T(".GIF")) {
		imgSave.Save(sFPath, Gdiplus::ImageFormatGIF);
	}
	else {
		AfxMessageBox(_T("このフォーマットで、Saveはできません。"), MB_OK);
	}

	imgSave.ReleaseDC();

	dx11.fg_save = 0;
}



