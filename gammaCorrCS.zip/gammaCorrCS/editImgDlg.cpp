﻿// editImgDlg.cpp : 実装ファイル
//

#include "pch.h"
#include "gammaCorrCS.h"
#include "afxdialogex.h"
#include "editImgDlg.h"


// CeditImgDlg ダイアログ

IMPLEMENT_DYNAMIC(CeditImgDlg, CDialog)

CeditImgDlg::CeditImgDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CeditImgDlg, pParent)
{
	//モードレス
	Create(IDD_CeditImgDlg, pParent);

	hWnd = GetParent()->GetSafeHwnd();
	pDC = GetDC();
	hDC = pDC->GetSafeHdc();

	fg_catchP = 0;
	fg_henkou = 0;


	Width = 340;
	Height = 520;
	SetWindowPos(&wndTop, 0, 0, Width, Height, SWP_HIDEWINDOW);

	imgBack.Destroy();
	imgBack.CreateEx(Width, Height, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcBack = CDC::FromHandle(imgBack.GetDC());
	hdcBack = pdcBack->GetSafeHdc();

	imgWork.Destroy();
	imgWork.CreateEx(Width, Height, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcWork = CDC::FromHandle(imgWork.GetDC());
	hdcWork = pdcWork->GetSafeHdc();


	Haikei = RGB(200, 200, 220);
	brHaikei.CreateSolidBrush(Haikei);	//背景色ブラシ

	clearBack(pdcBack, 0, 0, Width, Height, Haikei);
	clearBack(pdcWork, 0, 0, Width, Height, Haikei);

	//トーンカーブ描画領域のオフセット
	ofX = 30;
	ofY = 110;

	//トーンカーブ描画領域より下のボタン領域のYオフセット
	btY0 = 400;

	//ボタンをセット
	setBT();

	//GDI+の初期化-----------------------------------
	GdiplusStartup(&token, &gsi, NULL);
	ARGB();	//αチャンネル付きカラーを使う

	reset();
	redraw();


}

CeditImgDlg::~CeditImgDlg()
{
	//GDI+解放----------------------------------
	GdiplusShutdown(token);

	imgBack.ReleaseDC();
	imgWork.ReleaseDC();

	ReleaseDC(pDC);
}

void CeditImgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CeditImgDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CeditImgDlg メッセージ ハンドラー

//キャンセル・ボタン*********************************
void CeditImgDlg::OnBnClickedCancel()
{

	CDialog::OnCancel();
}


//OnPaint()******************************************************************
void CeditImgDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	getWsize();
	redraw();

	// 描画メッセージで CDialog::OnPaint() を呼び出さないでください。
}


//背景・変更**********************************************************
HBRUSH CeditImgDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	switch (nCtlColor)
	{
	case CTLCOLOR_DLG:
		hbr = (HBRUSH)brHaikei;
		break;

	default:	break;
	}

	// TODO:  既定値を使用したくない場合は別のブラシを返します。
	return hbr;
}


//ウィンドウのクライアント領域の寸法取得***********************************
void CeditImgDlg::getWsize()
{
	RECT rect;

	GetClientRect(&rect);
	Width = (int)rect.right;
	Height = (int)rect.bottom;
	Wx0 = (int)rect.left;
	Wy0 = (int)rect.top;

}


//ウィンドウ位置更新*******************************************************
void CeditImgDlg::setWPos(int wx0, int wy0)
{
	SetWindowPos(&wndTop, wx0, wy0, Width, Height, SWP_HIDEWINDOW);

}


//テキストおよびボタンをセット***************************************************************
void CeditImgDlg::setBT()
{
	btY0 = 400;

	//テキスト
	texN = 6;

	text[0] = _T("　トーンカーブ");
	texRect[0] = { 10,10,120,40 };

	text[1] = _T("　モード");
	texRect[1].left = 24;	texRect[1].top = 46;
	texRect[1].right = texRect[1].left + 80;	texRect[1].bottom = texRect[1].top + 40;



	//ボタン
	btN = 5;
	hovNo = 0;

	btname[0] = _T(" RGB");
	btRect[0].left = 100;	btRect[0].top = 50;
	btRect[0].right = btRect[0].left + 50;	btRect[0].bottom = btRect[0].top + 30;

	btname[1] = _T(" R");
	btRect[1].left = 160;	btRect[1].top = 50;
	btRect[1].right = btRect[1].left + 22;	btRect[1].bottom = btRect[1].top + 30;

	btname[2] = _T(" G");
	btRect[2].left = 190;	btRect[2].top = 50;
	btRect[2].right = btRect[2].left + 22;	btRect[2].bottom = btRect[2].top + 30;

	btname[3] = _T(" B");
	btRect[3].left = 220;	btRect[3].top = 50;
	btRect[3].right = btRect[3].left + 22;	btRect[3].bottom = btRect[3].top + 30;


	btname[4] = _T("　元に戻す");
	btRect[4] = { 10,btY0 + 20,100,btY0 + 20 + 30 };


}



//再描画（全体）********************************
void CeditImgDlg::redraw()
{
	//トーンカーブ
	drawSpline();

	//ボタン
	drawAllBT(-1);
}


//ボタン領域の再描画***************************************************************************
void CeditImgDlg::drawAllBT(int hovNo)
{
	int i;

	//テキスト
	COLORREF texCol = RGB(70, 70, 70);
	for (i = 0; i < texN; i++) {
		clearBack(pdcBack, texRect[i].left, texRect[i].top,
			texRect[i].right - texRect[i].left, texRect[i].bottom - texRect[i].top, Haikei);

		textOut(pdcBack, texRect[i], 20, text[i], texCol);

		pDC->StretchBlt(texRect[i].left, texRect[i].top,
			texRect[i].right - texRect[i].left, texRect[i].bottom - texRect[i].top,
			pdcBack, texRect[i].left, texRect[i].top,
			texRect[i].right - texRect[i].left, texRect[i].bottom - texRect[i].top, SRCCOPY);
	}


	//ボタン
	for (i = 0; i < btN; i++) {
		drawBT(i, hovNo);

		pDC->StretchBlt(btRect[i].left, btRect[i].top,
			btRect[i].right - btRect[i].left, btRect[i].bottom - btRect[i].top,
			pdcBack, btRect[i].left, btRect[i].top,
			btRect[i].right - btRect[i].left, btRect[i].bottom - btRect[i].top, SRCCOPY);
	}
}


//ボタンの描画*******************************************************
void CeditImgDlg::drawBT(int no, int hovNo)
{
	CPen p(PS_SOLID, 1, RGB(0, 0, 200));
	CBrush b(Haikei);

	CPen p1(PS_SOLID, 1, Haikei);
	CBrush b1(Haikei);

	CPen p2(PS_SOLID, 1, RGB(150, 150, 150));

	//ホバー
	if (no == hovNo) {
		if (fg_ON[no] == 1) {
			pdcBack->SelectObject(p2);
			pdcBack->Rectangle(&btRect[no]);
		}
		pdcBack->SelectObject(p);
		pdcBack->SelectObject(b);
		pdcBack->Rectangle(&btRect[no]);
	}
	else {
		pdcBack->SelectObject(p1);
		pdcBack->SelectObject(b1);
		pdcBack->Rectangle(&btRect[no]);
		if (fg_ON[no] == 1) {
			pdcBack->SelectObject(p2);
			pdcBack->Rectangle(&btRect[no]);
		}
	}

	COLORREF texCol = RGB(10, 10, 10);
	textOut(pdcBack, btRect[no], 20, btname[no], texCol);

	p.DeleteObject();
	b.DeleteObject();
	p1.DeleteObject();
	b1.DeleteObject();
}



//リセット***************************************************************
void CeditImgDlg::reset()
{
	int i = 0;
	fg_henkou = 0;

	//トーンカーブ
	ofX = 30;
	ofY = 110;

	wPN = 3;
	gPt[0].X = (float)ofX;			gPt[0].Y = (float)(ofY + 255);
	gPt[1].X = (float)(ofX + 127);	gPt[1].Y = (float)(ofY + 127);
	gPt[2].X = (float)(ofX + 255);	gPt[2].Y = (float)ofY;

	gPtW[0].X = 0;			gPtW[0].Y = 255;
	gPtW[1].X = 127;		gPtW[1].Y = 127;
	gPtW[2].X = 255;		gPtW[2].Y = 0;

	for (i = 0; i < 256; i++) {
		gamY[i] = 1.0f;
	}

	//ヒストグラム（ポリゴン）を描画するための、始点と終点を設定
	gPtR[0].X = (float)ofX;
	gPtR[0].Y = ofY + 255.0f;
	gPtG[0].X = (float)ofX;
	gPtG[0].Y = ofY + 255.0f;
	gPtB[0].X = (float)ofX;
	gPtB[0].Y = ofY + 255.0f;

	gPtR[257].X = (float)ofX + 255;
	gPtR[257].Y = ofY + 255.0f;
	gPtG[257].X = (float)ofX + 255;
	gPtG[257].Y = ofY + 255.0f;
	gPtB[257].X = (float)ofX + 255;
	gPtB[257].Y = ofY + 255.0f;

	//ヒストグラム
	for (i = 1; i < 257; i++) {
		gPtR[i].X = (float)(i + ofX);
		gPtR[i].Y = (float)(ofY + 255);
		gPtG[i].X = (float)(i + ofX);
		gPtG[i].Y = (float)(ofY + 255);
		gPtB[i].X = (float)(i + ofX);
		gPtB[i].Y = (float)(ofY + 255);
	}

	//ボタンの初期状態
	fg_ON[0] = 1;	//RGBがON
	fg_R = 1;
	fg_G = 1;
	fg_B = 1;
	fg_ON[1] = 0;
	fg_ON[2] = 0;
	fg_ON[3] = 0;
	fg_post = 0;
}



//Ｌボタン・ダウン******************************************************************
void CeditImgDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();//キャプチャ開始

	CPoint mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxD = mspoint.x;
	myD = mspoint.y;

	bmxM = mxD;
	bmyM = myD;

	int i = 0;
	int j = 0;
	catchPNo = -1;
	btNoD = -1;

	int fg = 0;
	PointF ptF[10];
	PointF ptFW[10];
	unsigned char* pCol = 0;
	long y;
	int S = 7;

	if (mxD > 0 && mxD < Width && myD >ofY + 300 && myD < Height ||
		mxD >0 && mxD < Width && myD >0 && myD < ofY) {
		for (i = 0; i < btN; i++) {
			if (mxD > btRect[i].left && mxD<btRect[i].right && myD>btRect[i].top &&
				myD < btRect[i].bottom) {
				btNoD = i;
				break;
			}
		}
	}
	//ガンマ補正
	else if (mxD >= ofX && mxD < ofX + 256 && myD >= ofY && myD < ofY + 256) {
		for (i = 1; i < wPN - 1; i++) {
			if (mxD > (int)gPt[i].X - S && mxD<(int)gPt[i].X + S && myD>(int)gPt[i].Y - S &&
				myD < (int)gPt[i].Y + S) {

				mxD = (int)gPt[i].X;
				myD = (int)gPt[i].Y;
				bmxM = mxD;
				bmyM = myD;
				CPoint pt(mxD, myD);
				ClientToScreen(&pt);
				SetCursorPos(pt.x, pt.y);
				gPtW[i].X = (float)(mxD - ofX);	gPtW[i].Y = (float)(myD - ofY);
				fg = 1;
				catchPNo = i;
				fg_catchP = 1;
				redraw();
			}
		}

		//ポイント追加(max5)------------------------------------------------------------------------
		if (fg == 0 && wPN < 6) {
			for (i = 0; i < wPN; i++) {
				ptF[i].X = gPt[i].X;		ptF[i].Y = gPt[i].Y;
				ptFW[i].X = gPtW[i].X;		ptFW[i].Y = gPtW[i].Y;
			}

			for (y = 0; y < 256; y++)
			{
				pCol = (unsigned char*)imgWork.GetPixelAddress(mxD - ofX, y);

				if (pCol[0] == 255 && y > myD - ofY - S && y < myD - ofY + S) {
					ptF[wPN].X = gPt[wPN - 1].X;			ptF[wPN].Y = gPt[wPN - 1].Y;
					ptFW[wPN].X = gPtW[wPN - 1].X;		ptFW[wPN].Y = gPtW[wPN - 1].Y;

					for (i = 1; i < wPN; i++) {
						if (mxD <= gPt[i].X) {
							ptF[i].X = (float)mxD;			ptF[i].Y = (float)(ofY + y);
							ptFW[i].X = (float)(mxD - ofX);	ptFW[i].Y = (float)y;
							catchPNo = i;
							break;
						}
					}

					for (j = catchPNo + 1; j < wPN; j++) {
						ptF[j].X = gPt[j - 1].X;		ptF[j].Y = gPt[j - 1].Y;
						ptFW[j].X = gPtW[j - 1].X;		ptFW[j].Y = gPtW[j - 1].Y;
					}

					wPN++;
					for (i = 0; i < wPN; i++) {
						gPt[i].X = ptF[i].X;		gPt[i].Y = ptF[i].Y;
						gPtW[i].X = ptFW[i].X;		gPtW[i].Y = ptFW[i].Y;
					}
					fg_catchP = 1;
					redraw();
					break;
				}
			}
		}
	}


	CDialog::OnLButtonDown(nFlags, point);
}


//マウス・ムーブ***********************************************************************
void CeditImgDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	CPoint pt;
	GetCursorPos(&pt);
	ScreenToClient(&pt);
	mxM = pt.x;
	myM = pt.y;

	int		i;
	int		hovNo = -1;

	if (mxM != bmxM || myM != bmyM) {

		if (mxM > 0 && mxM < Width && myM >ofY + 300 && myM < Height ||
			mxM > 0 && mxM < Width && myM >0 && myM < ofY) {
			for (i = 0; i < btN; i++)
			{
				if (mxM > btRect[i].left && mxM<btRect[i].right && myM>btRect[i].top &&
					myM < btRect[i].bottom)
				{
					hovNo = i;
					break;
				}
			}

			drawAllBT(hovNo);
		}
		//ガンマ補正
		else if (nFlags == MK_LBUTTON && fg_catchP == 1 && mxM >= ofX && mxM < ofX + 256 &&
			myM >= ofY && myM < ofY + 256) {

			if (catchPNo > 0 && catchPNo < wPN - 1) {

				gPt[catchPNo].X = (float)mxM;	gPt[catchPNo].Y = (float)myM;
				gPtW[catchPNo].X = (float)(mxM - ofX);	gPtW[catchPNo].Y = (float)(myM - ofY);
				drawSpline();
			}
		}
	}


	bmxM = mxM;
	bmyM = myM;

	CDialog::OnMouseMove(nFlags, point);
}


//Ｌボタン・アップ*************************************************************************
void CeditImgDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	CPoint pt;
	GetCursorPos(&pt);
	ScreenToClient(&pt);
	mxU = pt.x;
	myU = pt.y;
	ReleaseCapture();//キャプチャ終了

	int i = 0;
	btNoU = -2;

	if (mxU > 0 && mxU < Width && myU >ofY + 300 && myU < Height ||
		mxU > 0 && mxU < Width && myU >0 && myU < ofY) {
		for (i = 0; i < btN; i++) {
			if (mxU > btRect[i].left && mxU<btRect[i].right && myU>btRect[i].top &&
				myU < btRect[i].bottom) {
				btNoU = i;
				if (i == 0) {	//RGB最優先
					fg_ON[0] = 1;
					fg_R = 1;
					fg_G = 1;
					fg_B = 1;
					fg_ON[1] = 0;
					fg_ON[2] = 0;
					fg_ON[3] = 0;
				}
				else if (i == 1) {//R
					fg_ON[1] = 1;
					fg_R = 1;
					fg_G = 0;
					fg_B = 0;
					fg_ON[0] = 0;
					fg_ON[2] = 0;
					fg_ON[3] = 0;
				}
				else if (i == 2) {//G
					fg_ON[2] = 1;
					fg_R = 0;
					fg_G = 1;
					fg_B = 0;
					fg_ON[0] = 0;
					fg_ON[1] = 0;
					fg_ON[3] = 0;
				}
				else if (i == 3) {//B
					fg_ON[3] = 1;
					fg_R = 0;
					fg_G = 0;
					fg_B = 1;
					fg_ON[0] = 0;
					fg_ON[1] = 0;
					fg_ON[2] = 0;
				}

				break;
			}
		}

		if (btNoU == btNoD) {
			switch (btNoU)
			{
			case 0://モードRGB
				fg_R = 1;
				fg_G = 1;
				fg_B = 1;
				redraw();
				break;

			case 1://モードR
				fg_R = 1;
				fg_G = 0;
				fg_B = 0;
				redraw();
				break;

			case 2://モードG
				fg_R = 0;
				fg_G = 1;
				fg_B = 0;
				redraw();
				break;

			case 3://モードB
				fg_R = 0;
				fg_G = 0;
				fg_B = 1;
				redraw();
				break;


			case 4:	//元に戻す
				reset();
				redraw();
				break;

			default:break;

			}

			post();
		}
	}
	else if (mxU > ofX && mxU<ofX + 255 && myU>ofY && myU < ofY + 255) {
		if (fg_catchP == 1) {
			fg_henkou = 1;
		}
	}

	fg_catchP = 0;

	CDialog::OnLButtonUp(nFlags, point);
}



//ポストメッセージ******************************************
void CeditImgDlg::post()
{
	if (fg_post == 0) {
		::PostMessageW(hWnd, WM_Edit, 0, 0);
		fg_post = -1;
	}
}



//バックバッファにトーンカーブを描画し、ガンマ値を割り出す***********************
void CeditImgDlg::drawSpline()
{
	//バックバッファにトーンカーブ曲線を描画
	Graphics g1(hdcWork);
	g1.SetSmoothingMode(SmoothingModeAntiAlias);

	clearBack(pdcWork, 0, 0, 256, 256, RGB(0, 0, 0));

	Pen pen1(Color(255, 255, 255, 255), 2.0f);
	pen1.SetStartCap(LineCapRound);
	pen1.SetEndCap(LineCapRound);

	g1.DrawCurve(&pen1, gPtW, wPN, 0.5f);

	//ガンマ値の読み取り-----------------------------------------
	unsigned char* pCol = 0;
	long x, y;
	int ct = 0;

	for (x = 0; x < 256; x++)
	{

		for (y = 0; y < 256; y++)
		{
			pCol = (unsigned char*)imgWork.GetPixelAddress(x, y);
			if (pCol[0] == 255) {
				if (ct == 0) {
					gamY[ct] = 1.0f;
				}
				else {
					gamY[ct] = (float)(255 - y) / (float)ct;
				}
				break;
			}
		}

		if (gamY[ct] <= 0.0f) {
			gamY[ct] = 0.01f;
		}
		ct++;
	}

	post();
}


//ヒストグラムの描画****************************************************************
void CeditImgDlg::drawHG()
{
	Graphics g(hdcBack);
	g.SetSmoothingMode(SmoothingModeAntiAlias);// None);// AntiAlias);

	int i = 0;

	clearBack(pdcBack, ofX, ofY, 256, 256, Haikei);

	Pen pen1(Color(255, 100, 100, 100), 1.0f);
	pen1.SetStartCap(LineCapRound);
	pen1.SetEndCap(LineCapRound);

	Pen pen2(Color(255, 20, 20, 20), 1.0f);
	pen2.SetStartCap(LineCapRound);
	pen2.SetEndCap(LineCapRound);

	Pen pen3(Color(255, 200, 100, 0), 1.0f);
	pen3.SetStartCap(LineCapRound);
	pen3.SetEndCap(LineCapRound);

	Pen pen4(Color(255, 30, 30, 30), 2.0f);
	pen4.SetStartCap(LineCapRound);
	pen4.SetEndCap(LineCapRound);

	Pen pen5(Color(255, 200, 200, 200), 1.0f);
	pen5.SetStartCap(LineCapRound);
	pen5.SetEndCap(LineCapRound);

	//SolidBrush br1(Color(200, 255, 0, 0));

	//枠-------------------------------------------------------
	PointF ptF[8];
	ptF[0].X = (float)(ofX - 1);			ptF[0].Y = (float)(ofY - 1);
	ptF[1].X = (float)(ofX - 1);			ptF[1].Y = (float)(ofY + 255 + 1);
	ptF[2].X = (float)(ofX + 255 + 1);		ptF[2].Y = (float)(ofY + 255 + 1);
	ptF[3].X = (float)(ofX + 255 + 1);		ptF[3].Y = (float)(ofY - 1);
	g.DrawPolygon(&pen1, ptF, 4);

	ptF[4].X = (float)(ofX - 1);			ptF[4].Y = (float)(ofY + 127);
	ptF[5].X = (float)(ofX + 255 + 1);		ptF[5].Y = (float)(ofY + 127);
	ptF[6].X = (float)(ofX + 128);			ptF[6].Y = (float)(ofY - 1);
	ptF[7].X = (float)(ofX + 128);			ptF[7].Y = (float)(ofY + 255 + 1);
	g.DrawLine(&pen5, ptF[4], ptF[5]);
	g.DrawLine(&pen5, ptF[6], ptF[7]);


	//gamma値1.0のライン
	PointF ptF1[2];
	ptF1[0].X = (float)ofX/*+cRef*/;			ptF1[0].Y = (float)(ofY + 255);
	ptF1[1].X = (float)(ofX + 255/*-cRef*/);	ptF1[1].Y = (float)ofY;
	g.DrawLine(&pen3, ptF1[0], ptF1[1]);

	//トーンカーブ曲線
	g.DrawCurve(&pen2, gPt, wPN, 0.5f);

	//ピックアップ点（円）
	for (i = 1; i < wPN - 1; i++) {
		g.DrawEllipse(&pen4, gPt[i].X - 6, gPt[i].Y - 6, 12.0f, 12.0f);
	}

	//ヒストグラム描画
	SolidBrush br1(Color(120, 255, 0, 0));
	SolidBrush br2(Color(120, 0, 255, 0));
	SolidBrush br3(Color(120, 0, 0, 255));

	g.FillPolygon(&br1, gPtR, 258);
	g.FillPolygon(&br2, gPtG, 258);
	g.FillPolygon(&br3, gPtB, 258);

	pDC->StretchBlt(ofX - 1, ofY - 1, 258, 258, pdcBack, ofX - 1, ofY - 1, 258, 258, SRCCOPY);
}



//Backバッファimgサイズを任意の色でクリア************************************
void CeditImgDlg::clearBack(CDC* pdc, int x0, int y0, int w, int h, COLORREF Col)
{
	RECT rect = { x0,y0,x0 + w,y0 + h };
	CBrush cbr(Col);
	pdc->FillRect(&rect, &cbr);
	cbr.DeleteObject();
}




//テキストを描画***************************************************************************************
void CeditImgDlg::textOut(CDC* pdc, RECT rect, int nH, CString str, COLORREF tc)
{
	//新しいフォントを取得---------------------------------
	CFont font;
	font.CreateFont(
		nH,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		0,							// nWeight//FW_BOLD,
		FALSE,                     // bItalic
		FALSE,                     // bUnderline
		FALSE,                     // cStrikeOut
		SHIFTJIS_CHARSET,          // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		VARIABLE_PITCH | FF_SWISS,//ROMAN, // nPitchAndFamily
		_T("Meiryo UI"));					  // lpszFacename

	//新しいフォントで描画--------------------------------
	pdc->SelectObject(&font);
	pdc->SetTextColor(tc);
	//pdc->SetBkColor(bkc);
	pdc->SetBkMode(TRANSPARENT);

	CRect crect(rect.left, rect.top, rect.right, rect.bottom);

	UINT nFormat;
	if (str == _T("▼")) {
		nFormat = DT_CENTER | /*DT_LEFT |*/ DT_VCENTER | DT_SINGLELINE;
	}
	else {
		nFormat = /*DT_CENTER |*/DT_LEFT | DT_VCENTER | DT_SINGLELINE;
	}
	pdc->DrawText(str, crect, nFormat);

	//fontの開放
	font.DeleteObject();

}


