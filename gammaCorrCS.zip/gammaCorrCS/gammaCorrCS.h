﻿
// gammaCorrCS.h : PROJECT_NAME アプリケーションのメイン ヘッダー ファイルです
//

#pragma once

#ifndef __AFXWIN_H__
	#error "PCH に対してこのファイルをインクルードする前に 'pch.h' をインクルードしてください"
#endif

#include "resource.h"		// メイン シンボル


// CgammaCorrCSApp:
// このクラスの実装については、gammaCorrCS.cpp を参照してください
//

class CgammaCorrCSApp : public CWinApp
{
public:
	CgammaCorrCSApp();

// オーバーライド
public:
	virtual BOOL InitInstance();

// 実装

	DECLARE_MESSAGE_MAP()
};

extern CgammaCorrCSApp theApp;
