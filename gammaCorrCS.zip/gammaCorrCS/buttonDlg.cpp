﻿// buttonDlg.cpp : 実装ファイル
//

#include "pch.h"
#include "gammaCorrCS.h"
#include "afxdialogex.h"
#include "buttonDlg.h"


// CbuttonDlg ダイアログ

IMPLEMENT_DYNAMIC(CbuttonDlg, CDialog)

CbuttonDlg::CbuttonDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CbuttonDlg, pParent)
{
	//モードレス
	Create(IDD_CbuttonDlg, pParent);

	hWnd = GetParent()->GetSafeHwnd();
	pDC = GetDC();

	Haikei = RGB(0, 0, 0);
	brHaikei.CreateSolidBrush(Haikei);//背景色ブラシ

	//ウィンドウを半透明にする
	//Windowのプロパティレイヤー化をTRUEにする、
	SetLayeredWindowAttributes(Haikei, 190, LWA_ALPHA);


	texCol = RGB(120, 190, 255);

	SetWindowPos(&wndTop, 0, 0, 140, 400, SWP_HIDEWINDOW);
	getWsize();

	imgBack.Destroy();
	imgBack.CreateEx(Width, Height, 32, BI_RGB, 0, CImage::createAlphaChannel);
	pdcImgBack = CDC::FromHandle(imgBack.GetDC());

	bmxM = 0;
	bmyM = 0;


	btname[0] = _T("Load Image");
	btname[1] = _T("Save Image");
	btname[2] = _T("Focus");
	btname[3] = _T("Tone Curve");


	btN = 4;
	btHeight = 40;
	int		ofY = 30;
	int bTop = 0;

	int i;
	for (i = 0; i < btN; i++)
	{

		btRect[i].left = 0;
		btRect[i].top = bTop + ofY;
		btRect[i].right = 140;
		btRect[i].bottom = btRect[i].top + btHeight;

		bTop = btRect[i].bottom;
	}

	btNoD = -1;

}

CbuttonDlg::~CbuttonDlg()
{
	imgBack.ReleaseDC();

	ReleaseDC(pDC);
}

void CbuttonDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CbuttonDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()



// CbuttonDlg メッセージ ハンドラー

//背景・変更**********************************************************
HBRUSH CbuttonDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	switch (nCtlColor)
	{
	case CTLCOLOR_DLG:
		hbr = (HBRUSH)brHaikei;
		break;

	default:	break;
	}

	// TODO:  既定値を使用したくない場合は別のブラシを返します。
	return hbr;
}




//OnPaint()******************************************************************
void CbuttonDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	setBT();

	// 描画メッセージで CDialog::OnPaint() を呼び出さないでください。
}



//ウィンドウ位置更新*************************************************
void CbuttonDlg::setWpos(int x0, int y0, UINT swp)
{
	SetWindowPos(&wndTop, x0, y0, Width, Height, swp);
}



//ウィンドウのクライアント領域の寸法取得***********************************
void CbuttonDlg::getWsize()
{
	RECT rect;

	GetClientRect(&rect);
	Width = (int)rect.right;
	Height = (int)rect.bottom;
	Wx0 = (int)rect.left;
	Wy0 = (int)rect.top;

}


//全ボタンをセット********************************************************
void CbuttonDlg::setBT()
{
	clearBack(pdcImgBack, 300, 1000, Haikei);

	COLORREF Col;

	for (int i = 0; i < btN; i++)
	{
		Col = texCol;

		if (i == 3) {
			Col = RGB(0, 255, 50);
		}

		drawText(btname[i], btRect[i], Col);
	}

	pDC->BitBlt(0, 0, Width, Height, pdcImgBack, 0, 0, SRCCOPY);
}


//Ｌボタン・ダウン***********************************************************
void CbuttonDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	CPoint mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxD = mspoint.x;
	myD = mspoint.y;

	int i;
	btNoD = -1;

	for (i = 0; i < btN; i++)
	{
		if (mxD > btRect[i].left && mxD<btRect[i].right && myD>btRect[i].top
			&& myD < btRect[i].bottom)
		{
			btNoD = i;
			break;
		}
	}

	CDialog::OnLButtonDown(nFlags, point);
}


//マウス・ムーブ***********************************************
void CbuttonDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	CPoint mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxM = mspoint.x;
	myM = mspoint.y;

	CDialog::OnMouseMove(nFlags, point);
}


//Ｌボタン・アップ***********************************************************
void CbuttonDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	CPoint mspoint;
	GetCursorPos(&mspoint);
	ScreenToClient(&mspoint);
	mxU = mspoint.x;
	myU = mspoint.y;

	int i;
	btNoU = -1;

	for (i = 0; i < btN; i++)
	{
		if (mxU > btRect[i].left && mxU<btRect[i].right && myU>btRect[i].top
			&& myU < btRect[i].bottom)
		{
			btNoU = i;

			if (btNoD == -1 || btNoU != btNoD) {
				;
			}
			else {
				::PostMessageW(hWnd, WM_BT, btNoU, 2);//2=LButtonUP
			}

			break;
		}
	}

	CDialog::OnLButtonUp(nFlags, point);
}


//Backバッファを任意の色でクリア************************************
void CbuttonDlg::clearBack(CDC* pdc, int w, int h, COLORREF Col)
{
	RECT rect = { 0,0,w,h };
	CBrush b(Col);
	pdc->FillRect(&rect, &b);
	b.DeleteObject();
}


//テキストを描画*****************************************************************
void CbuttonDlg::drawText(CString cst, RECT rect, COLORREF txCol)
{
	//新しいフォントを取得---------------------------------
	CFont font;
	font.CreateFont(
		20,                        // nHeight
		0,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		FW_BOLD,				   // FW_NORMAL,
		FALSE,                     // bItalic
		FALSE,                     // bUnderline
		FALSE,                     // cStrikeOut
		SHIFTJIS_CHARSET,          // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		VARIABLE_PITCH | FF_SWISS,//ROMAN, // nPitchAndFamily
		_T("ＭＳゴシック"));					  // lpszFacename

	//新しいフォント選択する
	CFont* def_font = pdcImgBack->SelectObject(&font);

	//新しいフォントで描画--------------------------------
	//dc.SetTextColor(RGB(70,90,80));
	pdcImgBack->SetBkColor(Haikei);
	pdcImgBack->SetBkMode(TRANSPARENT);
	pdcImgBack->SetTextColor(txCol);

	UINT nFormat = DT_CENTER | DT_VCENTER | DT_SINGLELINE;//ここでは固定
	CRect crect;

	crect.left = rect.left;
	crect.top = rect.top;
	crect.right = rect.right;
	crect.bottom = rect.bottom;

	pdcImgBack->DrawText(cst, crect, nFormat);

	//fontの開放
	font.DeleteObject();

}




