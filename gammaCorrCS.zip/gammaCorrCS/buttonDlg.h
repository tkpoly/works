﻿#pragma once
#include "afxdialogex.h"

//メイン・クラスへのPostMessageメッセージ番号
#define WM_BT (WM_USER + 0x0000) 


// CbuttonDlg ダイアログ

class CbuttonDlg : public CDialog
{
	DECLARE_DYNAMIC(CbuttonDlg)

public:
	CbuttonDlg(CWnd* pParent = nullptr);   // 標準コンストラクター
	virtual ~CbuttonDlg();
	
	HWND	hWnd;	//親ウィンドウの
	CDC* pDC;

	CImage		imgBack;
	CDC* pdcImgBack;

	int			Width, Height;
	int			Wx0, Wy0;
	int			mxD, myD, mxM, myM, mxU, myU;
	int			bmxM, bmyM;
	CBrush		brHaikei;
	COLORREF	Haikei;
	CString		btname[4];
	int			btN;
	int			btHeight;
	CRect		btRect[4];
	COLORREF	texCol;
	int			btNoD, btNoU;


	void		getWsize();
	void		setBT();
	void		setWpos(int, int, UINT);
	void		clearBack(CDC*, int, int, COLORREF);
	void		drawText(CString, RECT, COLORREF);



// ダイアログ データ
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CbuttonDlg };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV サポート

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
};
